//
//  OinkBlindsApp.swift
//  OinkBlinds
//
//  Created by MultiLab PRT 09 on 17/03/2025.
//

import SwiftUI

@main
struct OinkBlindsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
