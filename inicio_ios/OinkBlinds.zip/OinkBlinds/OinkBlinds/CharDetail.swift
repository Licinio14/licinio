//
//  CharDetail.swift
//  OinkBlinds
//
//  Created by MultiLab PRT 09 on 18/03/2025.
//

import SwiftUI

struct CharDetail: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CharDetail()
}
