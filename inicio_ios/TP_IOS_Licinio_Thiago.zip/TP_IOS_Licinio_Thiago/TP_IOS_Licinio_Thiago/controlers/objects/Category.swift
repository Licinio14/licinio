//
//  Category.swift
//  TP_IOS_Licinio_Thiago
//
//  Created by MultiLab PRT 09 on 25/03/2025.
//
struct Category : Decodable, Identifiable {
    let id: Int
    let name: String
}
