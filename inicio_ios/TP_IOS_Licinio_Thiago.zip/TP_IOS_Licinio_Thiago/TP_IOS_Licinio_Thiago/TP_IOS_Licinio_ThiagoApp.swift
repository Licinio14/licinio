//
//  TP_IOS_Licinio_ThiagoApp.swift
//  TP_IOS_Licinio_Thiago
//
//  Created by MultiLab PRT 09 on 25/03/2025.
//

import SwiftUI

@main
struct TP_IOS_Licinio_ThiagoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
